# Notes on testing repos

## Testing Repos
testing/zz_TestingRepos/remoteRepo1.git is a remote bare repo
testing/zz_TestingRepos/workingRepo1.git is a working repo connected to remoteRepo1.git 

This repo contains *master*, *branch1*, and *branch2*

**Reference Web Pages***

https://www.sitereq.com/post/3-ways-to-create-git-local-and-remote-repositories

https://saraford.net/2017/03/03/how-to-create-your-own-local-git-remote-repo-thats-not-hosted-on-a-git-server-bare-option-062/

## Create bare repo

1. cd to zz_TestingRepos
2. ```mkdir remoteRepo.git```
3. cd into remoteRepo.git
4. ```git init --bare```
5. ls -l to view all the bare repo files.dirs

## Create working repo and connecting bare remote repo

1. cd to zz_TestingRepos
2. ```git init workingRepo1```
3. ```touch readme.txt``` to create a file
4. ```git status``` to view git status
5. ```git add readme.txt``` or ```git add .``` to add to staging area
6. ```git commit -m "initial commit"``` to commit to working directory
7. ```git remote add origin "../remoteRepo.git"``` to add remote (created above) repo to working repo
8. ```git remote -v``` to verify remote add
remote and working. Probably not needed here
9. ```git push --set-upstream origin master``` to set upstream remote
10. ```git push origin master``` to push working to remote